//In the start all 4 LBs fill one by one
    //After that each row fills with new set of pixels
    
    module AXIController #(parameter PIXW = 8,parameter K_size = 9, parameter LB_size = 20)
                         (input clk_50M,
                          input rst,
                          input s_axis_tvalid,
                          input s_axis_tlast,
                          input all_strides_done,
                          input master_start,
                          input [7:0] pointer1, pointer2, pointer3, pointer4,
                                      pointer5, pointer6, pointer7, pointer8,
                                      pointer9, pointer10,
                          output reg rd_start, 
                          output WREADY1, WREADY2, WREADY3, WREADY4,
                                 WREADY5, WREADY6, WREADY7, WREADY8,
                                 WREADY9, WREADY10,
                          output reg [3:0] lb_state,
                          output wire write_en1, write_en2, write_en3, write_en4,
                                      write_en5, write_en6, write_en7, write_en8,
                                      write_en9, write_en10
                          );
    //---------------
    
    reg start_State;
    localparam START = 1'b0;
    localparam BTW = 1'b1;
    //----------------------
    reg [3:0] pointer_state ;
    localparam P1 = 4'd0;
    localparam P2 = 4'd1;
    localparam P3 = 4'd2;
    localparam P4 = 4'd3;
    localparam P5 = 4'd4;
    localparam P6 = 4'd5;
    localparam P7 = 4'd6;
    localparam P8 = 4'd7;
    localparam P9 = 4'd8;
    localparam P10 = 4'd9;
    //-----BTW state param----
    localparam buf1 = 4'd0;
    localparam buf2 = 4'd1;
    localparam buf3 = 4'd2;
    localparam buf4 = 4'd3;
    localparam buf5 = 4'd4;
    localparam buf6 = 4'd5;
    localparam buf7 = 4'd6;
    localparam buf8 = 4'd7;
    localparam buf9 = 4'd8;
    localparam buf10 = 4'd9;
    //----------------------
    reg [3:0] current_row;
    reg check; 
    reg row_full;
    reg math_done;
    //---------------------
    // write_en fires when stream is valid and that LB is ready
    assign write_en1 = s_axis_tvalid && WREADY1 && check;
    assign write_en2 = s_axis_tvalid && WREADY2 && check;
    assign write_en3 = s_axis_tvalid && WREADY3 && check;
    assign write_en4 = s_axis_tvalid && WREADY4 && check;
    assign write_en5 = s_axis_tvalid && WREADY5 && check;
    assign write_en6 = s_axis_tvalid && WREADY6 && check;
    assign write_en7 = s_axis_tvalid && WREADY7 && check;
    assign write_en8 = s_axis_tvalid && WREADY8 && check;
    assign write_en9 = s_axis_tvalid && WREADY9 && check;
    assign write_en10 = s_axis_tvalid && WREADY10 && check;
    
    assign WREADY1 = (current_row == 0 && master_start && rst && !row_full) ? 1 : 0 ;
    assign WREADY2 = (current_row == 1 && master_start && rst && !row_full) ? 1 : 0 ;
    assign WREADY3 = (current_row == 2 && master_start && rst && !row_full) ? 1 : 0 ;
    assign WREADY4 = (current_row == 3 && master_start && rst && !row_full) ? 1 : 0 ;
    assign WREADY5 = (current_row == 4 && master_start && rst && !row_full) ? 1 : 0 ;
    assign WREADY6 = (current_row == 5 && master_start && rst && !row_full) ? 1 : 0 ;
    assign WREADY7 = (current_row == 6 && master_start && rst && !row_full) ? 1 : 0 ;
    assign WREADY8 = (current_row == 7 && master_start && rst && !row_full) ? 1 : 0 ;
    assign WREADY9 = (current_row == 8 && master_start && rst && !row_full) ? 1 : 0 ;
    assign WREADY10 = (current_row == 9 && master_start && rst && !row_full) ? 1 : 0 ;
    
    
    always @(posedge clk_50M or negedge rst) begin
        if(!rst) begin
            rd_start    <= 1'b0;
            lb_state    <= buf10;
            start_State <= START;
            current_row <= 4'd0;
            check       <= 1'b0;
            pointer_state <= P1;
            row_full    <= 1'b0;
            math_done   <= 1'b0;
        end
        else if (!master_start) begin 
            rd_start    <= 1'b0;
            lb_state    <= buf10;
            start_State <= START;
            current_row <= 4'd0;
            check       <= 1'b0;
            pointer_state <= P1;
            row_full    <= 1'b0;
            math_done   <= 1'b0;
        end
        else begin
            if(all_strides_done) math_done <= 1'b1;
            else if(rd_start) math_done <= 1'b0;

            case(start_State) 
                START : begin
                    check <= 1'b1;
                    rd_start <= 1'b0;
                    if(s_axis_tvalid) begin
                        case(pointer_state) 
                            P1 : begin
                                if(pointer1 == LB_size - 1 && WREADY1) begin
                                    current_row <= 4'd1;
                                    pointer_state <= P2;
                                end
                                else begin
                                    current_row <= 4'd0;
                                    pointer_state <= P1;
                                end
                            end
                            P2 : begin
                             if(pointer2 == LB_size - 1 && WREADY2) begin
                                    current_row <= 4'd2;
                                    pointer_state <= P3;
                                end
                                else begin
                                    current_row <= 4'd1;
                                    pointer_state <= P2;
                                end
                            end
                            P3 : begin
                             if(pointer3 == LB_size - 1 && WREADY3) begin
                                    current_row <= 4'd3;
                                    pointer_state <= P4;
                                    end
                                else begin
                                    current_row <= 4'd2;
                                    pointer_state <= P3;
                                end
                            end 
                            P4 : begin
                             if(pointer4 == LB_size - 1 && WREADY4) begin
                                    current_row <= 4'd4;
                                    pointer_state <= P5;
                                end
                                else begin
                                    current_row <= 4'd3;
                                    pointer_state <= P4;
                                end
                            end
                            P5 : begin
                             if(pointer5 == LB_size - 1 && WREADY5) begin
                                    current_row <= 4'd5;
                                    pointer_state <= P6;
                                end
                                else begin
                                    current_row <= 4'd4;
                                    pointer_state <= P5;
                                end
                            end 
                            P6 : begin
                             if(pointer6 == LB_size - 1 && WREADY6) begin
                                    current_row <= 4'd6;
                                    pointer_state <= P7;
                                end
                                else begin
                                    current_row <= 4'd5;
                                    pointer_state <= P6;
                                end
                            end 
                            P7 : begin
                             if(pointer7 == LB_size - 1 && WREADY7) begin
                                    current_row <= 4'd7;
                                    pointer_state <= P8;
                                end
                                else begin
                                    current_row <= 4'd6;
                                    pointer_state <= P7;
                                end
                            end 
                            P8 : begin
                             if(pointer8 == LB_size - 1 && WREADY8) begin
                                    current_row <= 4'd8;
                                    pointer_state <= P9;
                                end
                                else begin
                                    current_row <= 4'd7;
                                    pointer_state <= P8;
                                end
                            end 
                            P9 : begin
                             if(pointer9 == LB_size - 1 && WREADY9) begin
                                    current_row <= 4'd9;
                                    pointer_state <= P10;
                                    rd_start <= 1'b1;
                                end
                                else begin
                                    current_row <= 4'd8;
                                    pointer_state <= P9;
                                end
                            end  
                            P10 : begin
                                if(pointer10 == LB_size - 1 && WREADY10) begin
                                    start_State <= BTW;
                                    lb_state <= buf1;
                                    current_row <= 4'd0;
                                    rd_start <= 1'b1;
                                end
                                else begin
                                    current_row <= 4'd9;
                                    pointer_state <= P10;
                                end
                            end
                        endcase
                    end
                end
                BTW : begin
                    rd_start <= 1'b0;
                    if(s_axis_tlast) check <= 1'b0;
                    
                    case(lb_state)
//--------------------------------------
                        buf1 : begin
                            if(pointer1 ==  LB_size - 1 && s_axis_tvalid && WREADY1) begin
                                if(math_done || all_strides_done) begin  //after buffer is filled, if math is also done move on
                                    current_row <= 4'd1;
                                    lb_state <= buf2;
                                    rd_start <= 1'b1;
                                end
                                else begin  //math is slower than buf
                                    row_full <= 1'b1;
                                end
                            end
                            else if(row_full && all_strides_done) begin
                            // We were paused, math just finished, resume!
                                row_full <= 1'b0;
                                current_row <= 4'd1;
                                lb_state <= buf2;
                                rd_start <= 1'b1;
                            end
                        end    
//--------------------------------------------
                        buf2 : begin
                            if(pointer2 ==  LB_size - 1 && s_axis_tvalid && WREADY2) begin
                                if(math_done || all_strides_done) begin  //after buffer is filled, if math is also done move on
                                    current_row <= 4'd2;
                                    lb_state <= buf3;
                                    rd_start <= 1'b1;
                                end
                                else begin  //math is slower than buf
                                    row_full <= 1'b1;
                                end
                            end
                            else if(row_full && all_strides_done) begin
                            // We were paused, math just finished, resume!
                                row_full <= 1'b0;
                                current_row <= 4'd2;
                                lb_state <= buf3;
                                rd_start <= 1'b1;
                            end
                        end
//--------------------------------------------
                        buf3 : begin
                            if(pointer3 ==  LB_size - 1 && s_axis_tvalid && WREADY3) begin
                                if(math_done || all_strides_done) begin  //after buffer is filled, if math is also done move on
                                    current_row <= 4'd3;
                                    lb_state <= buf4;
                                    rd_start <= 1'b1;
                                end
                                else begin  //math is slower than buf
                                    row_full <= 1'b1;
                                end
                            end
                            else if(row_full && all_strides_done) begin
                            // We were paused, math just finished, resume!
                                row_full <= 1'b0;
                                current_row <= 4'd3;
                                lb_state <= buf4;
                                rd_start <= 1'b1;
                            end
                        end
//--------------------------------------------
                        buf4 : begin
                            if(pointer4 ==  LB_size - 1 && s_axis_tvalid && WREADY4) begin
                                if(math_done || all_strides_done) begin  //after buffer is filled, if math is also done move on
                                    current_row <= 4'd4;
                                    lb_state <= buf5;
                                    rd_start <= 1'b1;
                                end
                                else begin  //math is slower than buf
                                    row_full <= 1'b1;
                                end
                            end
                            else if(row_full && all_strides_done) begin
                            // We were paused, math just finished, resume!
                                row_full <= 1'b0;
                                current_row <= 4'd4;
                                lb_state <= buf5;
                                rd_start <= 1'b1;
                            end
                        end    
//--------------------------------------------
                        buf5 : begin
                            if(pointer5 ==  LB_size - 1 && s_axis_tvalid && WREADY5) begin
                                if(math_done || all_strides_done) begin  //after buffer is filled, if math is also done move on
                                    current_row <= 4'd5;
                                    lb_state <= buf6;
                                    rd_start <= 1'b1;
                                end
                                else begin  //math is slower than buf
                                    row_full <= 1'b1;
                                end
                            end
                            else if(row_full && all_strides_done) begin
                            // We were paused, math just finished, resume!
                                row_full <= 1'b0;
                                current_row <= 4'd5;
                                lb_state <= buf6;
                                rd_start <= 1'b1;
                            end
                        end  
//--------------------------------------------
                        buf6 : begin
                            if(pointer6 ==  LB_size - 1 && s_axis_tvalid && WREADY6) begin
                                if(math_done || all_strides_done) begin  //after buffer is filled, if math is also done move on
                                    current_row <= 4'd6;
                                    lb_state <= buf7;
                                    rd_start <= 1'b1;
                                end
                                else begin  //math is slower than buf
                                    row_full <= 1'b1;
                                end
                            end
                            else if(row_full && all_strides_done) begin
                            // We were paused, math just finished, resume!
                                row_full <= 1'b0;
                                current_row <= 4'd6;
                                lb_state <= buf7;
                                rd_start <= 1'b1;
                            end
                        end  
//--------------------------------------------
                        buf7 : begin
                            if(pointer7 ==  LB_size - 1 && s_axis_tvalid && WREADY7) begin
                                if(math_done || all_strides_done) begin  //after buffer is filled, if math is also done move on
                                    current_row <= 4'd7;
                                    lb_state <= buf8;
                                    rd_start <= 1'b1;
                                end
                                else begin  //math is slower than buf
                                    row_full <= 1'b1;
                                end
                            end
                            else if(row_full && all_strides_done) begin
                            // We were paused, math just finished, resume!
                                row_full <= 1'b0;
                                current_row <= 4'd7;
                                lb_state <= buf8;
                                rd_start <= 1'b1;
                            end
                        end  
//--------------------------------------------
                        buf8 : begin
                            if(pointer8 ==  LB_size - 1 && s_axis_tvalid && WREADY8) begin
                                if(math_done || all_strides_done) begin  //after buffer is filled, if math is also done move on
                                    current_row <= 4'd8;
                                    lb_state <= buf9;
                                    rd_start <= 1'b1;
                                end
                                else begin  //math is slower than buf
                                    row_full <= 1'b1;
                                end
                            end
                            else if(row_full && all_strides_done) begin
                            // We were paused, math just finished, resume!
                                row_full <= 1'b0;
                                current_row <= 4'd8;
                                lb_state <= buf9;
                                rd_start <= 1'b1;
                            end
                        end  
//--------------------------------------------
                        buf9 : begin
                            if(pointer9 ==  LB_size - 1 && s_axis_tvalid && WREADY9) begin
                                if(math_done || all_strides_done) begin  //after buffer is filled, if math is also done move on
                                    current_row <= 4'd9;
                                    lb_state <= buf10;
                                    rd_start <= 1'b1;
                                end
                                else begin  //math is slower than buf
                                    row_full <= 1'b1;
                                end
                            end
                            else if(row_full && all_strides_done) begin
                            // We were paused, math just finished, resume!
                                row_full <= 1'b0;
                                current_row <= 4'd9;
                                lb_state <= buf10;
                                rd_start <= 1'b1;
                            end
                        end  
//--------------------------------------------
                        buf10 : begin
                            if(pointer10 ==  LB_size - 1 && s_axis_tvalid && WREADY10) begin
                                if(math_done || all_strides_done) begin  //after buffer is filled, if math is also done move on
                                    current_row <= 4'd0;
                                    lb_state <= buf1;
                                    rd_start <= 1'b1;
                                end
                                else begin  //math is slower than buf
                                    row_full <= 1'b1;
                                end
                            end
                            else if(row_full && all_strides_done) begin
                            // We were paused, math just finished, resume!
                                row_full <= 1'b0;
                                current_row <= 4'd0;
                                lb_state <= buf1;
                                rd_start <= 1'b1;
                            end
                        end  
                                                                        
                    endcase
                end
            endcase
        end
    end
    endmodule