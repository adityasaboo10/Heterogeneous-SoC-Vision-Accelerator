(* keep_hierarchy = "yes" *) module Vector_Engine #(
    parameter PIXW = 8,
    parameter Output_Width = 32,
    parameter Kernel_size = 9 // 9x9 = 81 total
)(
    input clk_50M,
    input rst,
    input en,
    input [(Kernel_size * Kernel_size * PIXW)-1 : 0] ifMAP_flat,
    input [(Kernel_size * Kernel_size * PIXW)-1 : 0] weights,
    input [(Kernel_size * Kernel_size * Output_Width)-1 : 0] bias,
    output reg signed [Output_Width-1 : 0] out,
    output done
);

    // MAC outputs
    wire signed [Output_Width-1 : 0] mac_outputs [0 : 80];
    wire done_arr [0:80];

    // 1. Generate 81 PEs
    genvar idx;
    generate
        for(idx = 0; idx < Kernel_size * Kernel_size; idx = idx + 1) begin : gen_pe
            PE #(.PIXW(PIXW), .Output_Width(Output_Width)) u_pe (
                .clk_50M(clk_50M),
                .rst(rst),
                .a(ifMAP_flat[((idx+1)*PIXW)-1: idx*PIXW]),
                .b(weights[((idx+1)*PIXW)-1: idx*PIXW]),
                .c(bias[((idx+1)*Output_Width)-1: idx*Output_Width]),
                .en(en),
                .done(done_arr[idx]),
                .out(mac_outputs[idx])
            );
        end
    endgenerate

    // 2. PIPELINED ADDER TREE (Stage 1 & 2)
    reg signed [Output_Width-1 : 0] stage1_sum [0:8];
    reg signed [Output_Width-1 : 0] final_sum;
    reg [2:0] done_pipeline; // Track done signal through 2 stages

    integer i, j;
    always @(posedge clk_50M or negedge rst) begin
        if (!rst) begin
            for(i = 0; i < 9; i = i + 1) stage1_sum[i] <= 0;
            final_sum <= 0;
            out <= 0;
            done_pipeline <= 0;
        end else begin
            // Stage 1: Sum 9 groups of 9
            for (i = 0; i < 9; i = i + 1) begin
                stage1_sum[i] <= mac_outputs[i*9] + mac_outputs[i*9+1] + mac_outputs[i*9+2] + 
                                 mac_outputs[i*9+3] + mac_outputs[i*9+4] + mac_outputs[i*9+5] + 
                                 mac_outputs[i*9+6] + mac_outputs[i*9+7] + mac_outputs[i*9+8];
            end
            
            // Stage 2: Sum the 9 intermediate results
            final_sum <= stage1_sum[0] + stage1_sum[1] + stage1_sum[2] + 
                         stage1_sum[3] + stage1_sum[4] + stage1_sum[5] + 
                         stage1_sum[6] + stage1_sum[7] + stage1_sum[8];

            // Pipeline the result and the done signal
            out <= final_sum;
            done_pipeline <= {done_pipeline[1:0], done_arr[0]};
        end
    end

    assign done = done_pipeline[2]; // Latency-matched done signal

endmodule