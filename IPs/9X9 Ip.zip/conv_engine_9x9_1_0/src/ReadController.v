module ReadController #(parameter PIXW = 8, parameter K_size = 9, parameter LB_size = 256)
                 (input clk_50M,
                  input rst,
                  input rd_start,
                  input [3:0] lb_state,
                  input [(K_size*PIXW)-1:0] out_pix1, out_pix2, out_pix3, out_pix4, out_pix5, 
                                        out_pix6, out_pix7, 
                                        out_pix8,out_pix9, out_pix10,  //from line buffers
                  input master_start,
                  output reg all_strides_done,
                  output reg [7:0] base_pos,
                  output reg [(K_size * K_size * PIXW)-1:0] ifMAP_flat,
                  output vec_valid
                  );

//-----------------------
localparam buf1 = 4'd0;
localparam buf2 = 4'd1;
localparam buf3 = 4'd2;
localparam buf4 = 4'd3;
localparam buf5 = 4'd4;
localparam buf6 = 4'd5;
localparam buf7 = 4'd6;
localparam buf8 = 4'd7;
localparam buf9 = 4'd8;
localparam buf10 = 4'd9;

reg [7:0] rd_counter;
reg reading_active; //set high when rd_Start is high


assign vec_valid = (rst && master_start) ? reading_active : 1'b0;

// Sequential block: reading_active and stride counters
always @(posedge clk_50M or negedge rst) begin
    if (!rst) begin
        base_pos         <= 0;
        all_strides_done <= 0;
        rd_counter       <= 0;
        reading_active   <= 0;
    end
    else if (!master_start) begin
        base_pos         <= 0;
        all_strides_done <= 0;
        rd_counter       <= 0;
        reading_active   <= 0;
    end
    else begin
        all_strides_done <= 1'b0;

        // reading_active latch: set on rd_start, clear when strides done
        if (rd_start)
            reading_active <= 1'b1;
        else if (all_strides_done)
            reading_active <= 1'b0;

        // stride counter and base_pos
        if (reading_active) begin
            if (rd_counter < LB_size - K_size) begin
                base_pos   <= base_pos + 1;
                rd_counter <= rd_counter + 1;
            end
            else begin
                all_strides_done <= 1'b1;
                rd_counter       <= 0;
                base_pos         <= 0;
            end
        end
    end
end

// Combinational block: ifMAP_flat mux only
always @(*) begin
    ifMAP_flat = 0;
    if (rst && master_start) begin
        case (lb_state)
            //Top row of the image aligned with the Top row of your Keras weights.
           //top row -> bottom row of image :: lsb -> msb 
            buf1: ifMAP_flat = {out_pix10, out_pix9, out_pix8, out_pix7, out_pix6, out_pix5, out_pix4, out_pix3, out_pix2};
            buf2: ifMAP_flat = {out_pix1, out_pix10, out_pix9, out_pix8, out_pix7, out_pix6, out_pix5, out_pix4, out_pix3};
            buf3: ifMAP_flat = {out_pix2, out_pix1, out_pix10, out_pix9, out_pix8, out_pix7, out_pix6, out_pix5, out_pix4};
            buf4: ifMAP_flat = {out_pix3, out_pix2, out_pix1, out_pix10, out_pix9, out_pix8, out_pix7, out_pix6, out_pix5};
            buf5: ifMAP_flat = {out_pix4, out_pix3, out_pix2, out_pix1, out_pix10, out_pix9, out_pix8, out_pix7, out_pix6};
            buf6: ifMAP_flat = {out_pix5, out_pix4, out_pix3, out_pix2, out_pix1, out_pix10, out_pix9, out_pix8, out_pix7};
            buf7: ifMAP_flat = {out_pix6, out_pix5, out_pix4, out_pix3, out_pix2, out_pix1, out_pix10, out_pix9, out_pix8};
            buf8: ifMAP_flat = {out_pix7, out_pix6, out_pix5, out_pix4, out_pix3, out_pix2, out_pix1, out_pix10, out_pix9};
            buf9: ifMAP_flat = {out_pix8, out_pix7, out_pix6, out_pix5, out_pix4, out_pix3, out_pix2, out_pix1, out_pix10};
            buf10: ifMAP_flat = {out_pix9, out_pix8, out_pix7, out_pix6, out_pix5, out_pix4, out_pix3, out_pix2, out_pix1};
        endcase
    end
end

endmodule