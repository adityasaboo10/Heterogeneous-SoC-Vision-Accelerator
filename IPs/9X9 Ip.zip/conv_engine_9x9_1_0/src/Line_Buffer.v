module Line_Buffer #(parameter PIXW = 8, LB_size = 256, Kernel_size = 9)
   (input clk_50M,
    input rst, // active low
    input [PIXW-1 :0] inp_pix, 
    input write_en, 
    input [7:0] base_pos, 
    output [(Kernel_size* PIXW)-1:0] out_pix,
    output [7:0] pointer_out
    );
    
    assign pointer_out = pointer;

    // 1. Manually Replicate the Memory Array (9 Arrays for 9 Read Ports)
    (* ram_style = "block" *) reg [PIXW-1 : 0] LB_0 [LB_size-1 : 0];
    (* ram_style = "block" *) reg [PIXW-1 : 0] LB_1 [LB_size-1 : 0];
    (* ram_style = "block" *) reg [PIXW-1 : 0] LB_2 [LB_size-1 : 0];
    (* ram_style = "block" *) reg [PIXW-1 : 0] LB_3 [LB_size-1 : 0];
    (* ram_style = "block" *) reg [PIXW-1 : 0] LB_4 [LB_size-1 : 0];
    (* ram_style = "block" *) reg [PIXW-1 : 0] LB_5 [LB_size-1 : 0];
    (* ram_style = "block" *) reg [PIXW-1 : 0] LB_6 [LB_size-1 : 0];
    (* ram_style = "block" *) reg [PIXW-1 : 0] LB_7 [LB_size-1 : 0];
    (* ram_style = "block" *) reg [PIXW-1 : 0] LB_8 [LB_size-1 : 0];
    


    reg [7:0] pointer; 
    
    // Output Registers
    reg [PIXW-1 : 0] out0, out1, out2, out3, out4, out5, out6, out7, out8;

    wire [7:0] pos1 = (base_pos + 1 >= LB_size) ? (base_pos + 1 - LB_size) : (base_pos + 1);
    wire [7:0] pos2 = (base_pos + 2 >= LB_size) ? (base_pos + 2 - LB_size) : (base_pos + 2);
    wire [7:0] pos3 = (base_pos + 3 >= LB_size) ? (base_pos + 3 - LB_size) : (base_pos + 3);
    wire [7:0] pos4 = (base_pos + 4 >= LB_size) ? (base_pos + 4 - LB_size) : (base_pos + 4);
    wire [7:0] pos5 = (base_pos + 5 >= LB_size) ? (base_pos + 5 - LB_size) : (base_pos + 5);
    wire [7:0] pos6 = (base_pos + 6 >= LB_size) ? (base_pos + 6 - LB_size) : (base_pos + 6);
    wire [7:0] pos7 = (base_pos + 7 >= LB_size) ? (base_pos + 7 - LB_size) : (base_pos + 7);
    wire [7:0] pos8 = (base_pos + 8 >= LB_size) ? (base_pos + 8 - LB_size) : (base_pos + 8);

    // --------------------------------------------------------
    // BLOCK 1: Pointer Control (Allowed to have Asynchronous Reset)
    // --------------------------------------------------------
    always @(posedge clk_50M or negedge rst) begin
        if (!rst) begin
            pointer <= 0;
        end else if (write_en) begin
            if (pointer == LB_size - 1)
                pointer <= 0;
            else
                pointer <= pointer + 1;
        end
    end

    // --------------------------------------------------------
    // BLOCK 2: Pure BRAM Inference (NO RESET ALLOWED HERE!)
    // --------------------------------------------------------
    always @(posedge clk_50M) begin
        // Simultaneous Writes to all 3 blocks
        if (write_en) begin
            LB_0[pointer] <= inp_pix;
            LB_1[pointer] <= inp_pix;
            LB_2[pointer] <= inp_pix;
            LB_3[pointer] <= inp_pix;
            LB_4[pointer] <= inp_pix;
            LB_5[pointer] <= inp_pix;
            LB_6[pointer] <= inp_pix;
            LB_7[pointer] <= inp_pix;
            LB_8[pointer] <= inp_pix;
        end
        
        // Independent Synchronous Reads
        out0 <= LB_0[base_pos];
        out1 <= LB_1[pos1];
        out2 <= LB_2[pos2];
        out3 <= LB_3[pos3];
        out4 <= LB_4[pos4];
        out5 <= LB_5[pos5];
        out6 <= LB_6[pos6];
        out7 <= LB_7[pos7];
        out8 <= LB_8[pos8];
    end

    // Concatenate outputs
    assign out_pix = {out8, out7, out6, out5, out4, out3, out2, out1, out0};

endmodule