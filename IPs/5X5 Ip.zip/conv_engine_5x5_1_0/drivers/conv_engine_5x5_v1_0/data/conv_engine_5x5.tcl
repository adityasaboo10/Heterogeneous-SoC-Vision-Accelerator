

proc generate {drv_handle} {
	xdefine_include_file $drv_handle "xparameters.h" "conv_engine_5x5" "NUM_INSTANCES" "DEVICE_ID"  "C_S02_AXI_BASEADDR" "C_S02_AXI_HIGHADDR"
}
