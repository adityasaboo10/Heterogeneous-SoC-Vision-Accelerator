(* keep_hierarchy = "yes" *) module Vector_Engine #(
    parameter PIXW = 8,
    parameter Output_Width = 32,
    parameter Kernel_size = 5 // 5x5 = 25 total
)(
    input clk_50M,
    input rst,
    input en,
    input [(Kernel_size * Kernel_size * PIXW)-1 : 0] ifMAP_flat,
    input [(Kernel_size * Kernel_size * PIXW)-1 : 0] weights,
    input [(Kernel_size * Kernel_size * Output_Width)-1 : 0] bias,
    output reg signed [Output_Width-1 : 0] out,
    output done
);

    // MAC outputs
    wire signed [Output_Width-1 : 0] mac_outputs [0 : ((Kernel_size*Kernel_size) - 1)];
    wire done_arr [0:(Kernel_size*Kernel_size)-1];

    // 1. Generate 25 PEs
    genvar idx;
    generate
        for(idx = 0; idx < Kernel_size * Kernel_size; idx = idx + 1) begin : gen_pe
            PE #(.PIXW(PIXW), .Output_Width(Output_Width)) u_pe (
                .clk_50M(clk_50M),
                .rst(rst),
                .a(ifMAP_flat[((idx+1)*PIXW)-1: idx*PIXW]),
                .b(weights[((idx+1)*PIXW)-1: idx*PIXW]),
                .c(bias[((idx+1)*Output_Width)-1: idx*Output_Width]),
                .en(en),
                .done(done_arr[idx]),
                .out(mac_outputs[idx])
            );
        end
    endgenerate

    // 2. PIPELINED ADDER TREE (Stage 1 & 2)
    reg signed [Output_Width-1 : 0] stage1_sum [0:Kernel_size - 1];
    reg signed [Output_Width-1 : 0] final_sum;
    reg [2:0] done_pipeline; // Track done signal through 2 stages

    integer i, j;
    always @(posedge clk_50M or negedge rst) begin
        if (!rst) begin
            for(i = 0; i < Kernel_size; i = i + 1) stage1_sum[i] <= 0;
            final_sum <= 0;
            out <= 0;
            done_pipeline <= 0;
        end else begin
            // Stage 1: Sum 5 groups of 5
            for (i = 0; i < Kernel_size; i = i + 1) begin
                stage1_sum[i] <= mac_outputs[i*5] + mac_outputs[i*5+1] + mac_outputs[i*5+2] + 
                                 mac_outputs[i*5+3] + mac_outputs[i*5+4];
            end
            
            // Stage 2: Sum the 9 intermediate results
            final_sum <= stage1_sum[0] + stage1_sum[1] + stage1_sum[2] + 
                         stage1_sum[3] + stage1_sum[4];

            // Pipeline the result and the done signal
            out <= final_sum;
            done_pipeline <= {done_pipeline[1:0], done_arr[0]};
        end
    end

    assign done = done_pipeline[2]; // Latency-matched done signal

endmodule