module AXIS_Output_Wrapper #(parameter Width = 32) // 248 x 248
    (
    input clk_50M,
    input rst,
    //From Vector Engine
    input [Width-1:0] ve_out,
    input ve_done,
     input [31:0] active_total_pixels,
    // Outputs to the AXI DMA (S_AXIS_S2MM)
    output [Width-1:0] m_axis_tdata,
    output m_axis_tvalid,
    input  m_axis_tready,
    output m_axis_tlast
    );
    
assign m_axis_tdata = ve_out;
assign m_axis_tvalid = ve_done; // Syncs perfectly with data

reg [31:0] pixel_count;

always @(posedge clk_50M or negedge rst) begin
        if(!rst) begin
            pixel_count   <= 0;
        end
        else begin
            // Only increment count if data is valid AND DMA is ready to receive
            if (ve_done && m_axis_tready) begin
                if (pixel_count == active_total_pixels - 1) begin
                    pixel_count <= 0; // Reset for the next frame
                end else begin
                    pixel_count <= pixel_count + 1;
                end
            end
        end 
end

// tlast fires instantly on the very last valid pixel transfer
assign m_axis_tlast = (ve_done && m_axis_tready && (pixel_count == active_total_pixels - 1)) ? 1'b1 : 1'b0;

endmodule