module AXIS_Output_Wrapper #(parameter Width = 32) //256 x 256 + conv operation
    (
    input clk_50M,
    input rst, // Assuming active-low from Zynq (S_AXI_ARESETN)
    
    // From Vector Engine
    input [Width-1:0] ve_out,
    input ve_done,
    input [31:0] active_total_pixels,
    // Outputs to the AXI DMA (S_AXIS_S2MM)
    output [Width-1:0] m_axis_tdata,
    output m_axis_tvalid, // Changed to wire
    input  m_axis_tready,
    output m_axis_tlast   // Changed to wire
    );
    
    // 1. COMBINATORIAL ROUTING (Instantaneous)
    // Bind the data and valid signals tightly together so they never desync.
    assign m_axis_tdata = ve_out;
    assign m_axis_tvalid = ve_done;
    reg [31:0] pixel_count;
    // Drive tlast HIGH instantly if we are on the final pixel AND it is currently valid.
    assign m_axis_tlast = (pixel_count == (active_total_pixels - 1)) ? ve_done : 1'b0;

    // 2. SEQUENTIAL STATE (Clocked)
  

    always @(posedge clk_50M or negedge rst) begin
        if (!rst) begin
            pixel_count <= 0;
        end
        else begin
            // Only increment the counter if a successful handshake happens
            if (m_axis_tvalid && m_axis_tready) begin
                if (pixel_count == active_total_pixels - 1) begin
                    pixel_count <= 0; // Reset counter for the next image frame
                end else begin
                    pixel_count <= pixel_count + 1;
                end
            end
        end 
    end

endmodule